
1.Develop a shell script to print the username, current date & time, and current directory.
#!/bin/bash

echo -n "Username is: "
#x=whoami
#echo $x
whoami
echo -n "Current date and time: "
date
echo -n "Present working directory: "
pwd

2.Write a shell script to print sum of all digit of a given number.For e.g. If no is 123, sum of all its digit will be 1+2+3 = 6
#!/bin/bash

echo "Enter a number: "
read no

sum=0

while [ $no -gt 0 ]
do 
	digit=$((no%10))
	sum=$((sum+digit))
	no=$((no/10))
done

echo "The sum of all digit is : $sum"

3.Develop a shell script to compare three numbers and print the largest. Give the numbers from the
command line.
#!/bin/bash

read -p "Enter number 1 " no1
read -p "Enter number 2 " no2
read -p "Enter number 3 " no3

if [ $no1 -gt $no2 ] && [ $no1 -gt $no2 ]
then
	echo "$no1 is the largest"
elif [ $no2 -gt $no1 ] && [ $no2 -gt $no3 ]
then
	echo "$no2 is the largest"
elif [ $no3 -gt $no1 ] && [ $no3 -gt $no2 ]
then
	echo "$no3 is the largest"
else
	echo "Numbers equal"
fi

7.Write a shell script called calculator using case structure, which takes arguments from command
line eg., 2+3, 2*3 etc. and displays the result. It should perform the following operations:
a.Addition
b.Subtraction
c.Multiplication
d.Division
#!/bin/bash

echo "---CALCULATOR---"
echo "CAUTION: USE SPACE IN BETWEEN OPERAND AND OPERATOR "
echo ""
echo "OPERAND"
echo "Press + for Addition"
echo "Press - for Subtraction"
echo "Press * for Multiplication"
echo "Press / for Division"
echo "Press ^ for Power"
echo ""

read -p "" num1 op num2
#echo -n $num1 $operator $num2
operator=$op
result=1
if [ "$operator" == "+" ]
then
	result=$(( $num1+$num2 ))
elif [ "$operator" == "-" ]
then
	result=$(( $num1-$num2 ))
elif [ "$operator" == "*" ]
then
	result=$(( $num1*$num2 ))
elif [ "$operator" == "/" ]
then
	result=$(( $num1/$num2 ))
elif [ "$operator" == "^" ]
then
	for (( i=1; i<=num2; i++ ))
	do
		result=$(( $result*$num1 ))
	done
else
	echo "Invalid operator"
fi

echo -n " = $result"
echo ""

13.Write script to print given number in reverse order, for eg. If no is 123 it must print as 321
#!/bin/bash

echo "Enter a number: "
read no

reversed=0

while [ $no -gt 0 ]
do
	digit=$((no%10))
	reversed=$((reversed*10+digit))
	no=$((no/10))
done

echo "The number in reversed order is : $reversed"


14.Write script to print nos as 5,4,3,2,1 using while loop
#!/bin/bash

no=5

while [ $no -ge 1 ]
do
	echo $no
	no=$((no-1))
done


15.Write script to find out factorial for a given no
#!/bin/bash

echo "Enter a number: "
read number

factz=1

for (( i=1;i<=number;i++))
do
	factz=$((factz*i))
done

echo "Factorial of $number is $factz"





